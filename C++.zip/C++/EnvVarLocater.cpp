#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    print ("%s is located at %p", argv[1], getenv(argv[1])); 
}