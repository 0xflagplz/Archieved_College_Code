public class tiktactoe {



    public static void main(String[] args){

    }
}