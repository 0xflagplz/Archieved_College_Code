import java.util.*;
public class EvaluatePuzzle {
    public static int integerEval(String e)
    {
        int newVal = 0 ;
        String newExpression = "";
        for(int i = 0; i <=  e.length()-1; i++)                             // Start counting backwards through the equation looking for Last '('
        {
            if (e.charAt(i) == '(')                 // if found ...
            {
                String newEq = e.substring(i+1, e.length() -1);     //create a new substring from i+1 (i+1 is making the beggining of the substring before right after '('     )
                String beforeEq = e.substring(0, i+1);              // create copy of the equation before the evluating function
                for(int k = 0; k <= newEq.length(); k++)            // Go through another loop to subtract the last ')'
                {
                    if(newEq.charAt(k) == ')')                      // if found... which should be found according to rubric
                    {
                        newEq = newEq.substring(0, k-1);        // update snippet of total string to after the '(' and before the ')' something like this now -->(no parenthesis) + 2 3 5
                        String afterEq = e.substring(k+1, e.length() -1);    // create copy of equation of what comes after the evluating function
                        String op = checkOP(newEq);                                 // get operant value
                        String justNums = extracted(newEq);
                        newVal = getCalc(op, justNums);                            //get the calculation using new string of values and a string indentifying the Operant THEN SET TO INTEGER newVal
                        String SnewVal = String.valueOf(newVal);                // A string containing the new value
                        if (beforeEq != null){
                            newExpression = beforeEq + SnewVal;
                            if(afterEq != null) {
                                newExpression = newExpression + afterEq;
                            }
                        } else {
                            if(afterEq != null){
                                newExpression = SnewVal + afterEq;
                            }
                        }
                        integerEval(newExpression);         // working correctly should do : (+ 1 3 5 ( * 2 3 ) ) --> ( + 1 3 5 NewVal )
                                         
                        return newVal;                                               // ( + 1 3 5 NewVal ) being the new expression in integerEval
                    }
                }
            } 
            else                // if no '(' are found
            {
                newVal = Integer.valueOf(e);
                return newVal;                        
            }
        }
        return 0;                                          // else do nothing
    }

    private static String extracted(String newEq) {
        String justNums = newEq.substring(2, newEq.length);                   //remove the operant value from string
        return justNums;
    }

    public static int getCalc(String OP, String EQ){
        int result = 0;
		String[] Svalues = EQ.split(" ");               // take string, split into an Array of substrings at " "
		int[] values = new int[Svalues.length];         // create new int array to convert substrings into (same length as the String Array)
		for(int k = 0; i < Svalues.length;i++) {        // loop to put substrings in int array
		    values[i] = Integer.parseInt(Svalues[i]);   // convert to into and place inside new int array
        }
        if(OP.equals("+")){                                // if the givin Operant(OP) is +
            result = values[0];                             // set first value to result
            for(int i = 1; i < values.length-1; i = i+2){   // go through list, starting at [1] because [0] is already in result
                result = result + values[i];                 // update result      ( + 10 22 30 30) --> result(10) + 22 --> result(32) + 30 --> result(62) + 30 --> result(92)
            }
            return result;                                  //return it
        }
        else if(OP.equals("-")){                            // look at addition to see how it works
            result = values[0];
            for(int i = 1; i < values.length; i = i+2){
                result = result - values[i];
            }
            return result;
        }
        else if(OP.equals("*")){                            // look at addition to see how it works
            result = valus[0];
            for(int i = 1; i < values.length-1; i = i+2){
                result = result * values[i];
            }
            return result; 
        }
        else if(OP.equals("/")){                            // look at additionto see how it works
            result = values[0];
            for(int i = 1; i < values.length-1; i = i+2){
                result = result / values[i];
            }
            return result;
        }
        else {                                              // shouldnt have no OP but just in case
            result = values[0];
            return result;
        }
    }

    public static char checkOP(String x){                        // check what the Operator is
        char Operant;                             
        for(int i= s.length() -1; i >= 0; i--) {            // going backwards look for the operator
			if (x.charAt(i) == '+') {                       // if + set Operant to "+"
				Operant = '+';  
				break;                                      // break loop because found
			}   
			
			else if (x.charAt(i) == '-'){                      // look at addition to see how it works
				Operant = '-';
				break;
			}
				break;
			else if (x.charAt(i) == '*'){                      // look at addition to see how it works
				Operant = '*';
				break;
			}
			
			else if (x.charAt(i) == '/'){                      // look at addition to see how it works
				Operant = '/';
				break;
			}
            else{                                              // Again, shouldn't find no opperant but just in case
                System.out.println("No Opperant.");
                return Operant;
            }
        
        }
        return Operant;                                         //return the String 
    }

    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        System.out.println("Enter an expression: ");
        String input = in.nextLine();
        System.out.println(integerEval(input));

        in.close();
    }
}