import java.util.*;
public class PuzzleTest {

	public static void main(String[] args){
		Scanner in = new Scanner(System.in);
        System.out.println("Enter an expression: ");
        String input = in.nextLine();
        recursiveSolve(input);

        in.close();
    }

	private static boolean checkForP(String s) {
		if(e.contains("(")) {
			return True;
		}
		return False;
	}
	public static char checkOP(String s){                        // check what the Operator is                             
        for(int i= s.length() -1; i >= 0; i--) {            // going backwards look for the operator
			if (s.charAt(i) == '+') {                       // if + set Operant to "+"
				return '+';                                      // break loop because found
			}   
			
			if (s.charAt(i) == '-'){                      // look at addition to see how it works
				return '-'; 
			}
				break;
			if (s.charAt(i) == '*'){                      // look at addition to see how it works
				return '*';
			}
			
			if (s.charAt(i) == '/'){                      // look at addition to see how it works
				return '/'; 
			}
            else{                                              // Again, shouldn't find no opperant but just in case
                String noOP = "No Opperant.";
                return noOP;
            }
        
        }
        return Operant;                                         //return the String 
    }

	public static int evaluateEQ(String s){		//write evaluation method (checks sign, deletes it, converts from string, evals, return)
		int result= 0;
		char sign = checkOP(s);
		s = s.substring(2, s.length()-1);
		int[] listOfNum = new int[s.split(" ")];
		for(int i = 0; i < listOfNum.length; i++);
			if (sign == '+'){
				result = listOfNum[0];                             // set first value to result
				for(int i = 1; i < values.length-1; i = i+2){   // go through list, starting at [1] because [0] is already in result
					result = result + listOfNum[i];
				}
				return result;
			}
			if (sign == '-'){
				result = listOfNum[0];                             // set first value to result
				for(int i = 1; i < values.length-1; i = i+2){   // go through list, starting at [1] because [0] is already in result
					result = result - listOfNum[i];
				}
				return result;
			}
			if (sign == '/'){
				result = listOfNum[0];                             // set first value to result
				for(int i = 1; i < values.length-1; i = i+2){   // go through list, starting at [1] because [0] is already in result
					result = result / listOfNum[i];
				}
				return result;
			}
			if (sign == '*'){
				result = listOfNum[0];                             // set first value to result
				for(int i = 1; i < values.length-1; i = i+2){   // go through list, starting at [1] because [0] is already in result
					result = result * listOfNum[i];
				}
				return result;
			} else {
				return 0;
			}

	}

	public static int recursiveSolve(String e){
		boolean check = checkforP(e);
		if (check == true) {
			int firstP = e.lastIndexOf("(");
			int lastP = e.lastIndexOf(")");
			String seperated = e.substring(firstP+1, lastP-2);
			int evaluated = evaluateEQ(seperated);									//write evaluation method (checks sign, deletes it, converts from string, evals, return)
			String evalPrint = (String.parseString(evaluated));
			String removedEquation = e.substring(0, firstP-1) + evalPrint + e.substring(lastP+1, e.length()-1);
			recursiveSolve(removedEquation);
			System.out.println(removedEquation);			
			return evaluated;
		
		}
		else{
			e.trim();
			return Integer.parseInt(e);
			
			
		} 
		






	}

}