

import java.util.ArrayList;

public class QueensPuzzleSolver implements PuzzleTest
{
    
    //static ArrayList<boolean[][]> list;
    //static boolean[][] current;
    
    public static void main(String[] args)
    {
        ArrayList<boolean[][]> solution = solve(null, 0, 0);
        for(int i = 0; i < solution.size(); i++) {
            print(solution.get(i), i+1);
        }
    }
    
    //thoughts:
    //have an x value for the first starting queen, which others will use
    //have a y value for the first starting queen, which others will also use- only increments when x gets to 8, and x resets
    //if the program gets to the end of the grid without placing 8 queens, it increments x and moves on
    private static int counter = 0;
    public static ArrayList<boolean[][]> solve(ArrayList<boolean[][]> list, int x, int y) {
        if(list == null) list = new ArrayList<boolean[][]>();
        if(list.size() == 92) { 
            foundSolution(list);
        }
        else {
            boolean[][] current = new boolean[8][8];
            current[x][y] = true;
            int queens = 1;
            for(int i = 0; i < 8; i++) {
                if(queens == 8) break;
                for(int j = 0; j < 8; j++) {
                    if(queens == 8) break;
                    if(isPossible(current, i, j)) {
                        current[i][j] = true;
                        queens++;
                    }
                }
            }
            if(queens == 8) list.add(current);
            else {
                if (y == 7 && x == 7) return list;
                else if(x + 1 == 8) {
                    x = 0;
                    y++;
                } else {
                    x++;
                }
            }
            return solve(list, x, y);
        }
    }
    
    public static boolean isPossible(boolean[][] grid, int x, int y) {
        for(int i = 0; i < 8; i++) {
            for(int j = 0; j < 8; j++) {
                if(grid[i][j]) {
                    if(i == x) return false;
                    if(j == y) return false;
                    if(y-x == j-i) return false;
                }
            }
        }
        return true;
    }

    public boolean test(ArrayList candidate)
    {
        return false;
    }

    public static void foundSolution(ArrayList<boolean[][]> solution)
    {
        for(int i = 0; i < solution.size(); i++) {
            print(solution.get(i), i+1);
        }
        
    }
    
    public static void print(boolean[][] grid, int count) {
        System.out.println("Solution #" + count);
        printGrid(grid);
    }
    
    public static void printGrid(boolean[][] grid) {
        for(int i = 0; i < grid.length; i++) {
            for(int j =0; j < grid[0].length; j++) {
                if(!grid[i][j]) System.out.print("0 ");
                else System.out.print("1 ");
            }
            System.out.println();
        }
    }
}