from accounts import SavingsAccount, CheckingAccount
import tkinter as tk
from tkinter import messagebox

# Complete the code

gui = tk.Tk()
gui.title("Balance and Deposit")
myButtonGroup = tk.IntVar()
radChecking = tk.Radiobutton(gui, text='Checking', value=1)
radSavings = tk.Radiobutton(gui, text='Savings', value=1)
myButtonGroup.get()