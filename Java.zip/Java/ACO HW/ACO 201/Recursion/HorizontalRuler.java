import java.util.*;
public class HorizontalRuler {

    public static void drawHRuler(int length, int majorTickLength) {
        for (int j = majorTickLength; j >= 0; j--) {  //counting down to 0 line

            if (j != 0)
                System.out.print("| ");         // Setting 0 line
            else
                System.out.print(j + " ");      //adding 0 number label at the bottom j

            for (int i = 0; i < length; i++) {
                drawInterval(j, majorTickLength -1);    //call to create smaller speration ticks
                if (j == 0)
                    System.out.print((i + 1) + " "); // labeles the markers at bottom
                else
                    System.out.print("| ");   // creates remaining inch markers
            }
            System.out.println(); // creates space after the label 

        } 

    }

    public static void drawInterval(int j, int cLength) { //(2,3),(1,4),(3,2)
        
        }
    }

    public static void main(String[] args) {

        System.out.println("Horizontal Ruler - ");
        System.out.println("Ruler of length 2 with major stick length 4");
        drawHRuler(2, 4);

        System.out.println("Ruler of length 1 with major stick length 5");
        drawHRuler(1, 5);

        System.out.println("Ruler of length 3 with major stick length 3");
        drawHRuler(3, 3);
    } 
} 