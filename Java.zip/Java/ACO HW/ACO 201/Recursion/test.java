import java.util.*; 

public class test {
    public static void main(String[] args){
        Stack<String> STACK = new Stack<String>(); 
  
        // Use add() method to add elements 
        STACK.push("5"); 
        STACK.push("10"); 
        STACK.push("4"); 
        System.out.println("Initial Stack: " + STACK);
        System.out.println("Initial Stack: " + STACK.pop());

    }


}
