public class eightqueens {
    private int Queens = 8;
    ArrayList<Integer> seq = new ArrayList<Integer>();
    ArrayList<Integer> univ = new ArrayList<Integer>();
    




    public static void PuzzleSolve(int n, List<Integer> row, List<Integer> placement, List<List<Integer>> result){
        
        int counter = n;                                    //counts number of queens
        if(test.equals(false)){                                     //if the queen test failed
            seq.remove(seq.length-1);                          // backtrack and remove last seq
            PuzzleSolve(n)                                      // reattempt placement
        }
        else if(test.equals(true) || counter <= 0){}            // if true and 8 queens have been identified (counting down) print board
            foundSolution();
        }
                                                                
        PuzzleSolve(n-1, seq.get(n-1), univ, )                       //if counter is not equal to 0 solve for the next queen
        
        
    }
    private static class TestClass<Integer> implements PuzzleTest<Integer> {
        public boolean test(ArrayList<Integer> canididate) {  // returns true or false telling the function to backtrace or moveforward
            
            int cand = seq(canididate);
            for(int i = 1; i <= cand; i++){
                int test = seq(canididate-cand);
                if(test == cand){
                    return false;
                }
                else if(test == cand + i){
                    return false;
                }
                else if(test == cand - i){
                    return false;
                }
                else {
                    seq.add(canididate);
                    return true;
                }
            }
        }
            // You only need to worry about the diagonals
    

        public void foundSolution(ArrayList<Integer> solution) {  
            //print a pretty chessboard
            for(int i = 0; i < 8; i++){

                for (int k = 0; k < 8; k++){

                }
            }
        }
    }




    public static void main(String[] args){
        ArrayList<Integer> seq = new ArrayList<Integer>();
        ArrayList<Integer> univ = new ArrayList<Integer>();

        for (int i = 1; i <= 8; i++){                       //sets row numbers and values
            univ.add(i);
        }
        System.out.println("Name: Eddie Landers \n");
        System.out.println("Eight-Queens Puzzle: \n");
        PuzzleSolve.<Integer>solve(8, seq, univ, new QueenTest<Integer>());
    }
}
