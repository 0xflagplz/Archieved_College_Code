
public class SinglyLinkedList<E> {
	private static class Node<E> {
		private E element;
		private Node<E> next;

		public Node(E e, Node<E> n) {
			element = e;
			next = n;
		}

		public E getElement() {
			return element;
		}

		public Node<E> getNext() {
			return next;
		}

		public void setNext(Node<E> n) {
			next = n;
		}
	}

	private Node<E> head;
	private Node<E> tail;
	private int size;

	public SinglyLinkedList() {
		head = null;
		tail = null;
		size = 0;
	}

	public int length() {
		return size;
	}

	public boolean isEmpty() {
		return size == 0;
	}

	public E getFirst() {
		if (isEmpty()) {
			return null;
		}
		return head.getElement();
    }
    
    public E get(int n){

        if (n > size || isEmpty()){     //Checks for empty list or if queried for index not on list
            return null;
        }

        Node<E> temp = head;    //Pointer

        for(int i = 0; i <= size; i++){      //Temp walks through list until at the correct index
            if (i == n){
                return temp.getElement();   //Returns element if at correct index
            }
            temp = temp.next;
        }

        return null;    //Just in case something wacky happens
     }

	public E getLast() {
		if (isEmpty()) {
			return null;
		}
		return tail.getElement();
	}

	public void addFirst(E e) {
		head = new Node<E>(e, head);
		if (isEmpty()) {
			tail = head;
		}
		size++;
    }
    
    public void insertAfter(int n,E e){
        if(n >= size || isEmpty()){      //Returns if list is empty or n is greater than list size
            return;
        }

        Node<E> temp = head;    //Pointer

        for(int i = 0; i <= size; i++){
            if (i == n){    //Finds the correct insert point
                Node<E> insert = new Node<E>(e, null);  //Create new node insert
                insert.next = temp.next;    //Assigns new node's next to the node after it in the chain
                temp.next = insert;     //??Need a way to assign current node to inserted node??
            }
            temp = temp.next;
        }
		size++;
        return;
    }

	public void addLast(E e) {
		Node<E> newest = new Node<E>(e, null);
		if (isEmpty()) {
			head = newest;
		} else {
			tail.setNext(newest);
		}
		tail = newest;
		size++;
	}

	public E removeFirst() {
		if (isEmpty()) {
			return null;
		}

		E answer = head.getElement();
		head = head.getNext();
		size--;
		if (isEmpty()) {
			tail = null;
		}
		return answer;
    }

    public void delete(int n){
        if (n >= size || isEmpty()){    //checks if list is empty or if n is larger
            return;
        }
        if(n == size - 1) { // runs removeLast() if size == n
            removeLast();
            return;
        }
        if(n == 0){     //runs removeFirst() if 1 == size
            removeFirst();
            return;
        }

        Node<E> temp1 = head.next;    //Pointer 1, will lead
        Node<E> temp2 = head;    //Pointer 2, will follow

        for (int i = 1; i <= size; i++){
            if(i == n){
                temp2.next = temp1.next;    //Assign prior nodes next to the current nodes next to cut out current node
                return;
            }
            temp1 = temp1.next;     //walking the pointers
            temp2 = temp2.next;
        }
        return;
    }
    
    public E removeLast() {
        if (isEmpty()){
            return null;
		}
		if(size == 1){
			return removeFirst();
		}
		if(size == 2){
			E removed = head.next.getElement();     //create var to return removed value
			head.next = null;
			size--;
			return removed;
		}

        Node<E> temp = head;    //Pointer

        while(temp.next.next != null){     //Walk the list while the node two spaces forward is not null
            temp = temp.next;
        }

        E removed = temp.next.getElement();     //create var to return removed value
		temp.next = null;   //Severing link to last element
		tail = temp; 	//set tail to last
        size--;     //Decrementing size
        return removed;     //Returning removed value
    }
	
	public String toString() {
		String result = length() + ":[";
		for (Node<E> p = head; p != null; p = p.getNext()) {
			result += p.getElement();
			if (p.getNext() != null) {
				result += ", ";
			}
		}
		result += "]";
		return result;
	}
}

