
	import java.util.Scanner;

	public class RoundRobinSimulation {

		private final static int NUM_PROCESSES_INIT = 10;
		private final static int MAX_PROCESS_DURATION = 250;
		private final static int TIME_SLICE = 10;
		private final static double ADD_PROCESS_THRESHOLD = 0.03;
		private final static boolean VERBOSE_MODE = true;

		public static void main(String[] args) {
			CircularlyLinkedList<Process> processList = new CircularlyLinkedList<Process>();
			int processNum = 1;
			int simulationTime = 0;
			int sliceCount = 0;
			
			int timerVal = 0;
		    String Pname="";
		    int PnameVal=0;
		    String outPrint;
		    System.out.println("Enter Operation"); //prompts user for input
		    Scanner in = new Scanner(System.in);
		    

		    while(!in.next().equals("DONE")) {
		      timerVal = in.nextInt();
		      if (in.next().equals("ADD")) {
		        Pname = in.next();
		        PnameVal = in.nextInt();
		      
		        System.out.println(PnameVal);
			
				processList.addLast(new Process(Pname, PnameVal));
		    }

			while (!processList.isEmpty()) {
				if (VERBOSE_MODE) System.out.printf("@%05d %s\n", simulationTime, processList);
				
				Process p = processList.getFirst();
				int time = p.execute(TIME_SLICE);
				
				if (time == 0) {
					processList.removeFirst();
				} else {
					processList.rotate();
				}

				if (Math.random() < ADD_PROCESS_THRESHOLD) {
					if (VERBOSE_MODE) System.out.println("\n*** Added new Process " + Pname + " ***\n");
					processList.addLast(new Process(Pname, PnameVal));
				}

				simulationTime += TIME_SLICE;
				sliceCount++;
			}
			
			System.out.printf("\nSimulation ended at %05d. %d Processes were completed in %d time slices.\n", simulationTime, processNum-1, sliceCount);
		}
	}
}