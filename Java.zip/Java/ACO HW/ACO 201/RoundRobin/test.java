import java.util.ArrayList;
import java.io.IOException;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.File;
import java.util.List;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class test {

	private final static int NUM_PROCESSES_INIT = 10;
	private final static int MAX_PROCESS_DURATION = 250;
	private final static int TIME_SLICE = 10;
	private final static double ADD_PROCESS_THRESHOLD = 0.03;
	private final static boolean VERBOSE_MODE = true;

	public static void main(String[] args) throws IOException {
		CircularlyLinkedList<Process> processList = new CircularlyLinkedList<Process>();
		int processNum = 1;
		int simulationTime = 0;
		int sliceCount = 0;

		File file = new File("ProcessSequence1.txt");
		BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
		Scanner scanner = new Scanner(file);
	

    // the shit starts

				
		System.out.println("Instructions:");
		int Wordcount;		
		String line = null;
		while ((line = in.readLine()) != null) {
            System.out.println(line);
            Wordcount++;
        }
        Wordcount *= 5;
		String[] wordList = new String[Wordcount];
		for(int i = 0; scanner.hasNextLine(); i++){
            String currentLine = scanner.nextLine();
            wordList[] = currentLine.split(" ");
				
        }
        int lengthBefore = Wordcount;
        int lengthA = lengthBefore/5;
        int[] finalList = new int[lengthA];
        for(int i = 4; i < lengthBefore; i++){
            finalList[i] = Integer.parseInt(wordList[i*4]);
        }
        System.out.println(finalList);
        scanner.close();
        in.close();
        				
			
		//The shit ends
		
    }
}