import java.io.*;
class AdvRoundRobinSimulation
{
   public static void main(String args[]) throws IOException
   {
        DataInputStream input=new DataInputStream(System.in);
        int i,j,k,quant,sum=0;
        System.out.println("Enter number of process:");
        int n=Integer.parseInt(input.readLine());
        int burst_time[]=new int[n];
        int wait_time[]=new int[n];
        int turn_around_time[]=new int[n];
        int a[]=new int[n];
  
  
        System.out.println("Enter burst Time: ");
        
        
        for(i=0;i<n;i++)
        {
            System.out.println("Enter burst Time for " +(i+1));
            burst_time[i]=Integer.parseInt(input.readLine()); //taking input burst time of each process ,burst_time is execution time of process
        }
        
        
        System.out.println("Enter Time quantum:");
        quant=Integer.parseInt(input.readLine());
        
        
        for(i=0;i<n;i++)
            a[i]=burst_time[i];

        
        for(i=0;i<n;i++)
            wait_time[i]=0;
        
        
        do
        {
            for(i=0;i<n;i++)
            {
                if(burst_time[i]>quant)
                {
                    burst_time[i]-=quant; //updating burst time of process at every cycle
                    for(j=0;j<n;j++)
                    {
                        if((j!=i)&&(burst_time[j]!=0))
                        wait_time[j]+=quant; //updating wait time of process at every cycle
                    }
                }
                else
                {
                    for(j=0;j<n;j++)
                    {
                        if((j!=i)&&(burst_time[j]!=0))
                        wait_time[j]+=burst_time[i];   
                    }
                    burst_time[i]=0;   
                }
            }
            sum=0;
            for(k=0;k<n;k++)
            sum=sum+burst_time[k];
        } while(sum!=0); // do above steps until each and every process get executed
        
        
        for(i=0;i<n;i++)
        turn_around_time[i]=wait_time[i]+a[i]; // turnaround time is wait time of process + execution time of process
        
        
        System.out.println("process\t\tBT\tWT\tTAT");
        
        
        for(i=0;i<n;i++)
        {
            System.out.println("process"+(i+1)+"\t"+a[i]+"\t"+wait_time[i]+"\t"+turn_around_time[i]);
        }
        
        
        float avg_wait_time=0;
        float avg_turn_around_time=0;
        
        
        for(j=0;j<n;j++)
        {
            avg_wait_time+=wait_time[j];
        }
        
        for(j=0;j<n;j++)
        {
            avg_turn_around_time+=turn_around_time[j];
        }
        
        System.out.println("average waiting time "+(avg_wait_time/n)+"\nAverage turn around time"+(avg_turn_around_time/n));
        }

  
}