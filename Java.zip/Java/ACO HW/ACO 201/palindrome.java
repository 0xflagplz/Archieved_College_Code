import java.util.*;
public class palindrome {

    public static boolean palCheck(String S) {
        int length = S.length();
        if (length == 1 || length == 0){
            return true;
        }
        for(int i = 0; i < length; i++){
            if(S.charAt(i) == S.charAt((length-1)-i)){
                System.out.println("Letter " + S.charAt(i) + " is the same!");
            } else {
                System.out.println("It is not a palindrome :/");
                return false;
            }
        }
        System.out.println("It is a palindrome :)");
        return true;
        
    }

    public static void main(String[] args){
        int i = 1;
        while (i != 0){
            Scanner in = new Scanner(System.in);
            System.out.print("What is your word: ");
            String input = in.nextLine();
            palCheck(input);

            System.out.println("Would you like to continue?");
            String conQ = in.next();
            if (conQ.charAt(0) == 'n'){
                System.exit(0);
            } 
        }




    }
}
