

public class BigO
{

    int fillArray(int size){
        int array[] = new int[size];
        for (int i = 0; i < size; i++){
            int a = 11 * i;
            array[i] = a ;
            System.out.println(array[i]);
            return array[];
        }
    }

    public static void main(String[] args) 
    {
        BigO c = new BigO();  
        int theSizeofArray = 100;
        c.fillArray(theSizeofArray);
        
        

        


    }
}