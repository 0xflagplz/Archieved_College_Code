import os
import datetime
import time
import sys
from tkinter import Tk
from time import clock
from tkinter import *



#creating the clock
def tick():
    timeString = time.strftime("%I:%M:%S %p")
    clock.config(text=timeString)
    clock.after(200,tick)

#creates baclbone for program
mirrorRoot = Tk()


#adding clock to display
clock = Label(mirrorRoot, font = ("Candra", 100, "bold"), bg= "black", fg="white")
clock.grid(row=1, column=1)
tick()  

def escape(mirrorRoot):
    mirrorRoot.geometry("800x800")

def fullscreen(mirrorRoot):
    width, height = mirrorRoot.winfo_screenwidth(), mirrorRoot.winfo_screenheight()
    mirrorRoot.geometry("%dx%d+0+0" % (mirrorRoot.winfo_screenwidth(), mirrorRoot.winfo_screenheight()))


#Size of the background screen
mirrorRoot.geometry("%dx%d" % (mirrorRoot.winfo_screenwidth(), mirrorRoot.winfo_screenheight()))  #finds screen szie
mirrorRoot.overrideredirect(1) #removes border
mirrorRoot.configure(bg='black') #background color
mirrorRoot.bind("<Escape>", lambda a :escape(mirrorRoot))
mirrorRoot.bind("<F1>", lambda a :fullscreen(mirrorRoot))







# main function that facilitates the start of prgram
mirrorRoot.mainloop()


