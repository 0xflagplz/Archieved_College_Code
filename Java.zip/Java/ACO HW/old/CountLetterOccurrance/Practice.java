public class Practice {
   public static void main(String[] args) {

      System.out.println("test");
  }
 }