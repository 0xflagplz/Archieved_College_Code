import java.util.Scanner;





public class CountOccurancesInWord
{
   public static void main(String[] args)
   {
      Scanner in = new Scanner(System.in);
   
      System.out.println("Enter a word: ");
		String word = in.nextLine();
		
      System.out.println("Enter a char: ");
		char letter = in.next().charAt(0);
            
		
	  //Call the method countOccurrances
      int amount = CountOccurancesInWord.countOccurrances(word, letter);
	   //print out the letter, the word, and #occurance times
      System.out.println("Word: " + word);
      System.out.println("Letter: " + letter);
      System.out.println("Amount Letter Occured: " + amount);
      
      

   } 
   
   public static int countOccurrances(String word, char letter) 
   {
   
	//implement this method
      int numberOfOccurance = 0;
   
      for (int i = 0; i < word.length(); i++)
      {
     
         if (word.charAt(i) == letter) 
         {
            numberOfOccurance++;
            i++;
         }
      } 
      return numberOfOccurance;
      

   }  
    
}
      
