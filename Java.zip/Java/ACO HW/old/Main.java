import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
public class Main {
   
   
   
   
   
   public static void main(String[] args)
   {
   
      String s = "1234";
      for (int i = 0; i <= 5; i++)    // line 2
      {
      
         System.out.print(s.substring(i, i + 1));    // line 4
      
      }
   
   }
}