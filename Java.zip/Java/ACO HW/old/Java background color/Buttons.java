interface Buttons {
    
    TheButtons();
    
}