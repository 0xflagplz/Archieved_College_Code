
import java.awt.*; 
import javax.swing.*; 
import java.awt.event.*; 



public class colorBackground extends JFrame implements ActionListener {

    //defining the buttons to be used
    JRadioButton orangeButton;
    JRadioButton magentaButton;
    JRadioButton cyanButton;
    JRadioButton redButton;
    JRadioButton blueButton;
    JRadioButton greenButton;

    public JPanel p;
    public FlowLayout flow = new FlowLayout(1, 50, 100);
    public JPanel buttonPanel = new JPanel();
    public JPanel buttonPane2 = new JPanel();

    
   
    public void GuiMethod(){    //class that creates the interface
        
        // The whole frame
        this.setTitle("What Color?");
        this.setSize(1000, 1000);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        

        // Panel that displays color 
        p = new JPanel();
        p.setVisible(true);
        p.setSize(300, 300);
        p.setLocation(350, 350);
        p.setBackground(Color.black);
        this.add(p);

        buttonPanel.setVisible(true);
        buttonPanel.setSize(600, 50);
        buttonPanel.setLocation(200, 30);
        buttonPanel.setLayout(new FlowLayout(1, 75, 15));
        buttonPanel.add(orangeButton);
        buttonPanel.add(magentaButton);
        buttonPanel.add(cyanButton);


        buttonPane2.setVisible(true);
        buttonPane2.setSize(600, 50);
        buttonPane2.setLocation(200, 100);
        buttonPane2.setLayout(new FlowLayout(1, 75, 15));
        buttonPane2.add(redButton);
        buttonPane2.add(blueButton);
        buttonPane2.add(greenButton);

        this.add(buttonPanel);
        this.add(buttonPane2);

    }
   
    // Change the Background color constructor
    public colorBackground() {


        // making the buttons stated anf giving them content
        orangeButton = new JRadioButton("Orange");
        magentaButton = new JRadioButton("Magenta");
        cyanButton = new JRadioButton("Cyan");

        redButton = new JRadioButton("Red");
        blueButton = new JRadioButton("Blue");
        greenButton = new JRadioButton("Green");

        // Making Only 1 button selectable at a time
        ButtonGroup theButtons = new ButtonGroup();
        theButtons.add(orangeButton);
        theButtons.add(magentaButton);
        theButtons.add(cyanButton);
        theButtons.add(redButton);
        theButtons.add(blueButton);
        theButtons.add(greenButton);

                
        
        
        
        
        

        // Buttons are listening to be selected
        orangeButton.addActionListener(this);
        magentaButton.addActionListener(this);
        cyanButton.addActionListener(this);
        redButton.addActionListener(this);
        blueButton.addActionListener(this);
        greenButton.addActionListener(this);
        

    }

    // Updating when the buttons are selected 
    public void actionPerformed(ActionEvent event){
        String clickedButton = event.getActionCommand();

        // This is just to see in the console when selected
        System.out.println(clickedButton + " was selected!"); 

        // changing the color of background
        if(event.getSource() == orangeButton) {
            p.setBackground(Color.orange);
        }
        else if(event.getSource() == magentaButton){
            p.setBackground(Color.magenta);
        }
        else if(event.getSource() == cyanButton){
            p.setBackground(Color.cyan);
        }
        else if(event.getSource() == redButton){
            p.setBackground(Color.red);
        }
        else if(event.getSource() == blueButton){
            p.setBackground(Color.blue);
        }
        else if(event.getSource() == greenButton){
            p.setBackground(Color.green);
        }
    }


    public static void main(String[] args){
        colorBackground background = new colorBackground();
        background.GuiMethod();
        background.setLayout(null);
        
        
        
    }
}



