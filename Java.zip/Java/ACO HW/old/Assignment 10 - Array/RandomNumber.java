
import java.util.Arrays;
import java.util.ArrayList;
public class RandomNumber {


    
    public static void main(String[] args) {
        // cerate new Array named random with size of 23
        int[] random = new int[23];
        
        //create random value for all 23 
        for(int i = 0; i < random.length; i++) {
           random[i] = (int)(Math.random()*1000+999);
        }    
        //new Array in reverse order
        int[] reverseOrder = new int[23];
        int position = 0;
        for (int x = random.length - 1; x > 0; x--){
           reverseOrder[position] = random[x];
           position++;
        }
        
        //new Array less than 1500 and odd
        ArrayList<Integer> line3 = new ArrayList<Integer>();            //new Array (using ArrayList for changing Array length)
        for(int i = 0; i < random.length; i++){                         //check if belwo 1500 or odd
           if (random[i] < 1500 || random[i] % 2 != 0){
              line3.add(random[i]);
           }     
           
        }
        
        //new ArrayList that print every odd element larger than 1500, similar to line 3
        ArrayList<Integer> line4 = new ArrayList<Integer>();            //new Array (using ArrayList for changing Array length)
        for(int i = 0; i < random.length; i++){                         //check if belwo 1500 or odd
           if (random[i] > 1500 && random[i] % 2 != 0){
              line4.add(random[i]);
           }     
           
        }
 
        
        //Print array
        System.out.println("All elements in the Array: \n" + Arrays.toString(random));
        System.out.println();
        
        //Print elements in reverse order
        
        System.out.println("All elements in reverse order: \n" + Arrays.toString(reverseOrder));
        System.out.println();

        //Every element that is less than 1500 and also at an odd index 
        System.out.println("All elements less than 1500 or an odd value: \n" + line3);
        System.out.println();
        
      
        //Every odd element that is larger than 1500
        System.out.println("All elements greater than 1500 and an odd value: \n" + line4);
        System.out.println(); System.out.println();
        
        System.out.println("Edward Landers");
        
    }
}