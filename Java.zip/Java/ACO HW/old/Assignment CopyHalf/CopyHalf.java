import java.util.Arrays;
public class CopyHalf
{
   /**
      Copies the first half of an array. If the length is odd,
      
      don't copy the middle value.
      
      
      @param values an array
      
      @return a copy of the first half of values
   */
   public static String[] copyHalf(String[] values)
   {
      int LengthHalf = values.length / 2;
      String[] result = new String[LengthHalf];
      for (int i = 0; i < LengthHalf; i++) {
         result[i] = values[i];     
      }
      return result;

   }
}