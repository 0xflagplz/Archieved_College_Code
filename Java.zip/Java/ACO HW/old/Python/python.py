number = int(input("Enter a number : "))

check = number % 2

if check > 0:
    print("You picked an odd number!")

else:
    print("You picked an even number!")