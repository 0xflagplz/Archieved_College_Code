import random
import os
import string
import json
import requests

chars = string.ascii_letters + string.digits + '!@#$%^&*()'
random.seed = (os.urandom(1024))

url = 'PlaceRequestURLHere'

names = json.loads(open('names.json').read())

for name in names:
    name_extra = ''.join(random.choice(string.digits))

    username = name.lower() + name_extra + '@yahoo.com'
    password = ''.join(random.choice(chars) for i in range(10))

    requests.post(url, allow_redirects=False, data={
        'orgisfsdfsfsaadsfnal': username,     #Look for FORM DATA  inspectElement --> Network --> Headers
        'sgdfgsgdsgsfdsgfdsgf': password 
    })

    print 'sending username %s and password %s' % (username, password)   

    