import os, platform

print("OS Name: ", os.name)
print("CPU count: ", os.cpu_count())
print("Processor: ", platform.processor())
print()
print("Platform")
print("System: ", platform.system())
print("Architecture: ", platform.architecture())
