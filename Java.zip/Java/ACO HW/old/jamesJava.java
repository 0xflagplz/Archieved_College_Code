import java.util.*;  


public class jamesJava
{


    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);

        
        System.out.println("Input 4 Jobs and their Salary");
        System.out.println("Use this format \n   Job: xxxx");

        // Starting variables
        String job;
        int salary;
        int bottomSal = 999999;
        int topSal = 0;
      
        boolean truefalse = false;
        String topJob = "";
        String bottomJob = "";


        while (truefalse == false){

           //get user input
            String userInput = in.nextLine();
            

            // if user does not input, loop ENDS
            if (userInput.equals("")){
                truefalse = true;
                break;
                
            }
            
            // Split userInput at :, creates small array to seperate phrases
            String[] input = userInput.split(":");
            
            //assign first part of input to JOB variable
            job = input[0].trim();

            //assign second user part of userInput into int value
            salary = Integer.parseInt(input[1].trim());

            // saves highest value that input, then check if value is also lowest
            if (salary > topSal)
            {
                topSal = salary;
                topJob = job;      
                if(salary < bottomSal)
                {
                    bottomSal = salary;
                    bottomJob = job;
                }        
            }

            else if(salary < bottomSal)
            {
                bottomSal = salary;
                bottomJob = job;
                if (salary > topSal)
                {
                    topSal = salary;
                    topJob = job;  
                }
            }
            // clear substrings in input
            input = null;
            
            
         
        }
        String highestSalary = String.format("%,d", topSal);
        String lowestSalary = String.format("%,d", bottomSal);
        //Print results once loop is finished
        System.out.println("");
        System.out.println("Highest Salary: \n" + topJob + ": $" + highestSalary);
        System.out.println("");
        System.out.println("Lowest Salary: \n" + bottomJob + ": $" + lowestSalary);
        

        
        
        
       
    }



}
