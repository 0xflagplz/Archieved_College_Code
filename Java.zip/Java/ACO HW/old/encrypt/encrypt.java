import java.util.Scanner;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.util.Arrays;
import java.io.*;



public class encrypt 
{

    public static void main(String[] args) throws IOException
    {
        String FileName2 = args[0];

        Scanner file = new Scanner(new File(FileName2));
       
    
        PrintWriter writer = new PrintWriter("encrypted_"+ FileName2);

        while (file.hasNextLine())
        {
            
            System.out.println("");

            String LineBeingRead = file.nextLine();
            char[] reading = LineBeingRead.toCharArray();
        
            for (char c : reading)
            {
                c += 4;
                System.out.print(c);
                writer.append(c);
    
            }
            writer.write("\n");
            
        }
        writer.close();
    }


}