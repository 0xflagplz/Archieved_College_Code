import java.awt.*;
import java.util.ArrayList;

public class QueenPuzzleSolverOrigin {


    ArrayList<Tile[][]> seq = new ArrayList<>();
    public static void main(String[] args) {
        int x = 4;
        int y = 4;

        Tile [][] board = newBoard(0);
        System.out.println("Edward Landers - Best Attmept");
        for (int i=0; i < 8; i++)
        {
            solve(board,i,0,0);
            board = newBoard(0);
            
        }


//        board[x][y] = new Tile(true,true);
//
//        setDangerZone(board,x,y);
//        printBoard(board);

    }



    public static void printBoard(Tile[][] board) {
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                if (board[i][j].isQueen)
                {
                    System.out.print("Q ");
                }
                else if (board[i][j].isDangerZone())
                {
                    System.out.print("- ");
                }
                else
                    System.out.print("* ");
            }
            System.out.println();
        }
    }

    public static Tile[][] newBoard(int location)
    {
        Tile[][] board= new Tile[8][8];
        for (int i = 0; i < board.length; i++)
        {
            for (int j = 0; j < board[i].length; j++)
            {
                board[i][j] = new Tile(false,false);
            }
        }
        return board;
    }

    public static Point isPlaceable(Tile[][]board)
    {
        for (int i = 0; i < board.length; i++)
        {
            for (int j = 0; j < board[i].length; j++)
            {
                if (!board[i][j].isDangerZone())
                {
                    return new Point(i,j);
                }

            }
        }
        return null;
    }

    public static void setDangerZone(Tile[][]board,int x, int y)
    {
        int min = Math.min(x,y);
        int s = y;
        for (int i = 0; i < board.length; i++) //i is the x value
        {

            for (int j = 0; j < board[i].length; j++) // is y value
            {

                //columns
                if (j == y)
                {
                    board[i][j].setDangerZone(true);
                }

                //rows
                if (i == x)
                {
                    board[i][j].setDangerZone(true);
                }

                //odd diag
                if (i == j)
                {
                    int valX = x-min+i;
                    int valY = y-min+j;
                    if (valX < 8 && valY < 8)
                    {
                        board[valX][valY].setDangerZone(true);
                    }
                }
            }
            int valX = x+s-i;
            int valY = i;
            if (valX < 8 && valX >= 0 && valY < 8)
            {
                board[valX][valY].setDangerZone(true);
            }
        }

    }

    public static void solve(Tile[][] board,int x,int y,int counter)
    {
      
        
        Tile tile = board[x][y];
        if (tile.placeable())
        {
            tile.setQueen(true);
            setDangerZone(board,x,y); //todo look at x and y
            Point newPoint = isPlaceable(board);
            
	    if(counter == 7){
    
                System.out.println("\n\nThe first solution:\n\n");
                printBoard(board);
                return;
                

            }    
            if (newPoint == null)
            {
                if (!tile.placeable()){

                }
                    
            }else{
                counter++;
                solve(board, newPoint.x, newPoint.y,counter);
            
            }
            
        }
    }



}