import java.util.Scanner;
import java.lang.Math;



public class PostfixEvaluator {
	public static int evaluate(String expr) {
		ArrayStack<Integer> stack = new ArrayStack<Integer>(100);
		Scanner parser = new Scanner(expr);

		while (parser.hasNext()) {
			String token = parser.next();

			if ("&|+-*/%^<>=".indexOf(token) >= 0) {
				Integer op2 = stack.pop();
				Integer op1 = stack.pop();
				if (op1 == null || op2 == null) {
					throw new java.lang.ArithmeticException("Insufficient operands for " + token + ".");
				}
				

				
					//check to see if boolean operator
				stack.push(evaluateSingleOperator(token.charAt(0), op1, op2));
				
			} 
			else if("~!".indexOf(token) >= 0){
				Integer op2 = stack.pop();
				Integer op1 = stack.pop();
				if (op1 == null && op2 == null) {
					throw new java.lang.ArithmeticException("Insufficient operands for " + token + ".");
				}
				else{
					if(op1 == null){
						stack.push(SingleOp(token.charAt(0), op2, op2));
					}
					stack.push(SingleOp(token.charAt(0), op2, op2));
				}
			}

			else if("?".indexOf(token) >= 0){
				Integer op3 = stack.pop();
				Integer op2 = stack.pop();
				Integer op1 = stack.pop();

				if (op1 == null || op3 ==null || op2 == null) {
					throw new java.lang.ArithmeticException("Insufficient operands for " + token + ".");
				}
				
				stack.push(ternaryOperations(token.charAt(0), op1, op2, op3));

			}


			else {
				stack.push(Integer.parseInt(token));
			}
		}

		if (stack.size() != 1) {
			throw new java.lang.ArithmeticException("" + (stack.size() - 1) + " too few operators.");
		}
		
		return stack.pop();
		
	}

	private static int evaluateSingleOperator(char operation, int op1, int op2) {
		switch (operation) 
		{	
			
			case '+': return op1 + op2;
			case '-': return op1 - op2;
			case '*': return op1 * op2;
			case '/': return op1 / op2;
			case '%': return op1 % op2;
			case '^': int pow = 1; for(int z = 0; z < op2; z++){pow *= op1;} return pow;
			case '<': if (op1 < op2){return 1;} else {return 0;}
			case '>': if (op1 > op2){return 1;} else {return 0;}
			case '=': if (op1 == op2){return 1;} else {return 0;}
			case '&': if (op1 > 0 && op2 > 0) {return 1;} else {return 0;}
			case '|': if (op1 > 0 || op2 > 0) {return 1;} else {return 0;}
			
			default:  return 0;


		}
	}

	

	private static int SingleOp(char operation, int op1, int op2) {
		switch(operation) {
			case '~': return (op1 * -1);
			case '!': int factorial=1; for (int z = 1; z <=op1;z++){factorial *= z;} return factorial;
			default: return 0;
		}
	}


	private static int ternaryOperations(char operation, int op1, int op2, int op3) {
		switch(operation) {
			case '?': if (op3 >= 1){return op2;} else {return op1;}
			default: return 0;
		}
	}
}

	


